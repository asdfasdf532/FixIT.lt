import { pgTable, text, real, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const productsTable = pgTable("products", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  nameLt: text("name_lt").notNull(),
  description: text("description").notNull(),
  descriptionLt: text("description_lt").notNull(),
  category: text("category", {
    enum: [
      "computers",
      "laptops",
      "accessories",
      "monitors",
      "peripherals",
      "cables",
      "gaming",
    ],
  }).notNull(),
  price: real("price").notNull(),
  originalPrice: real("original_price"),
  inStock: boolean("in_stock").notNull().default(true),
  imageUrl: text("image_url"),
  specs: jsonb("specs").$type<Record<string, string>>(),
});

export const insertProductSchema = createInsertSchema(productsTable);
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
