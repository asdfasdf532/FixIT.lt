import { pgTable, text, real, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const servicesTable = pgTable("services", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  nameLt: text("name_lt").notNull(),
  description: text("description").notNull(),
  descriptionLt: text("description_lt").notNull(),
  category: text("category", {
    enum: [
      "diagnostics",
      "repair",
      "cleaning",
      "software",
      "hardware",
      "bios",
    ],
  }).notNull(),
  priceFrom: real("price_from").notNull(),
  priceTo: real("price_to"),
  durationDays: integer("duration_days"),
  popular: boolean("popular").notNull().default(false),
});

export const insertServiceSchema = createInsertSchema(servicesTable);
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof servicesTable.$inferSelect;
