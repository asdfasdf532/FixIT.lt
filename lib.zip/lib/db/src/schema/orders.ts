import { pgTable, text, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: text("id").primaryKey(),
  type: text("type", { enum: ["repair", "product", "pc_build"] }).notNull(),
  status: text("status", {
    enum: ["pending", "confirmed", "in_progress", "done", "cancelled"],
  })
    .notNull()
    .default("pending"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull(),
  description: text("description").notNull(),
  serviceId: text("service_id"),
  serviceName: text("service_name"),
  productIds: jsonb("product_ids").$type<string[]>().notNull().default([]),
  estimatedPrice: real("estimated_price"),
  estimatedPriceMax: real("estimated_price_max"),
  preferredDate: text("preferred_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  createdAt: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
